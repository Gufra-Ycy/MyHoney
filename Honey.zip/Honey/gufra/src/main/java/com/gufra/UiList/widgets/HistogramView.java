package com.gufra.UiList.widgets;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

public class HistogramView extends View {
    Paint mPaint;
    public HistogramView(Context context) {
        super(context);
    }

    public HistogramView(Context context,  AttributeSet attrs) {
        super(context, attrs);
    }

    public HistogramView(Context context,  AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        mPaint.setColor(Color.RED);
        canvas.drawText("HistogramView",0,0,mPaint);
    }

}
