package com.gufra.UiList.widgets;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

/**
 * TODO: document your custom view class.
 */
public class BasicView extends View {

    Paint mPaint;

    public BasicView(Context context) {
        super(context);

    }

    public BasicView(Context context, AttributeSet attrs) {
        super(context, attrs);

    }

    public BasicView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);

    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        mPaint.setStyle(Paint.Style.STROKE);

        canvas.drawLine(0,0,50,50,mPaint);
    }


}
