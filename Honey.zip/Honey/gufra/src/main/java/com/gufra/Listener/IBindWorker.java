package com.gufra.Listener;

/*
* 契约类，定义和 Service 之间交互的接口.
* */
public interface IBindWorker {

    void work();
}
