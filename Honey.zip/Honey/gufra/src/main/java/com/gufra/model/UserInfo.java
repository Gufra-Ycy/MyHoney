package com.gufra.model;
/*
* 用户实体
* */
public class UserInfo {
}
