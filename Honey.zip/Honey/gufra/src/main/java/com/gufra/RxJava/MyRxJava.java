package com.gufra.RxJava;

import rx.subjects.PublishSubject;

public class MyRxJava {
    PublishSubject publishSubject;
}
